//??? lo de ariba???
import "./styles.css";
import React from 'react';
import Titulo from "./Components/Titulo"
class App extends React.Component
{
  
  render(){
    return (
      <div className="App">
        <div className="page-header">
          <Titulo/>
        </div>
        <h1>a</h1>
      </div>
    );
  }
}
export default App;
